module.exports = {
    config: {
        'APPID': '',
        'APPSECRET': ''
    }
}