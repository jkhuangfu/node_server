# node_express_mySQL
个人学习Demo

此分之为session版本

增加微信 js-sdk

PS：运行方法 npm install 安装依赖
	
	
	 (1) npm run start

	 (2) pm2 start start.json (需要全局安装pm2 npm install -g pm2)

Mysql 表结构

1.user_main 用户信息表

![Image text](http://img.drnet.xyz/user_main.png)

2.article 博文表

![Image text](http://img.drnet.xyz/article.png)

3.message 用户留言信息

![Image text](http://img.drnet.xyz/message.png)
		

