/* test */
module.exports = {
    mysqlDev: {
        host: '127.0.0.1',
        user: 'root',
        password: 'huangfu',
        database: 'api',
        port: 3306
    },
    mysqlOnline: {
        host: '',
        user: '',
        password: '',
        database: '',
        port: ''
    }
};